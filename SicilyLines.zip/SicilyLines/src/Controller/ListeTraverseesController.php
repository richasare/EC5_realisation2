<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use App\Repository\TraverseeRepository;
use App\Entity\Traversee;
use App\Entity\Liaison;


class ListeTraverseesController extends AbstractController
{
    /**
     * @Route("/liste/traversees", name="liste_traversees")
     */
    public function findTraversee(TraverseeRepository $traversees): Response
    {
        $traversees = $this->getDoctrine()
        ->getRepository(Traversee::class)
        ->findAll();

        return $this->render('liste_traversees/index.html.twig', [
            'traversees' => $traversees,
        ]);
    }

    public function plusInfoTraversee(TraverseeRepository $traversees, $idTraversee): Response
    {

    }
}
