<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* liste_traversees/index.html.twig */
class __TwigTemplate_f114edbf168f8eecb4006d1dd8e2024365cd48bca8d34724787057a4ecf8fdde extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "liste_traversees/index.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "liste_traversees/index.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "<div class=\"container\">
<table class=\"table table-sm table-dark\">
  <thead>
    <tr>
      <th scope=\"col\">Date</th>
      <th scope=\"col\">Nom du bateau</th>
      <th scope=\"col\">Port de départ</th>
      <th scope=\"col\">Port d'arrivé</th>
    </tr>
  </thead>
  <tbody>
    
      
        ";
        // line 17
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["traversees"]) || array_key_exists("traversees", $context) ? $context["traversees"] : (function () { throw new RuntimeError('Variable "traversees" does not exist.', 17, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["traversee"]) {
            // line 18
            echo "            <tr>
            <td>";
            // line 19
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->source, $context["traversee"], "date", [], "any", false, false, false, 19), "y-m-d"), "html", null, true);
            echo "</td>
            <td>";
            // line 20
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["traversee"], "leBateau", [], "any", false, false, false, 20), "nom", [], "any", false, false, false, 20), "html", null, true);
            echo "</td>
            <td>";
            // line 21
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["traversee"], "laLiaison", [], "any", false, false, false, 21), "portDepart", [], "any", false, false, false, 21), "nom", [], "any", false, false, false, 21), "html", null, true);
            echo "</td>
            <td>";
            // line 22
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["traversee"], "laLiaison", [], "any", false, false, false, 22), "portArrivee", [], "any", false, false, false, 22), "nom", [], "any", false, false, false, 22), "html", null, true);
            echo "</td>
            <td><button type=\"button\" class=\"btn btn-info\">Plus d'infos</button></td>
            </tr>
            
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['traversee'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 27
        echo "    
    
  </tbody>
  </div>
</table>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "liste_traversees/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  104 => 27,  93 => 22,  89 => 21,  85 => 20,  81 => 19,  78 => 18,  74 => 17,  59 => 4,  52 => 3,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base.html.twig' %}

{% block body %}
<div class=\"container\">
<table class=\"table table-sm table-dark\">
  <thead>
    <tr>
      <th scope=\"col\">Date</th>
      <th scope=\"col\">Nom du bateau</th>
      <th scope=\"col\">Port de départ</th>
      <th scope=\"col\">Port d'arrivé</th>
    </tr>
  </thead>
  <tbody>
    
      
        {% for traversee in traversees %}
            <tr>
            <td>{{traversee.date | date('y-m-d')}}</td>
            <td>{{traversee.leBateau.nom}}</td>
            <td>{{traversee.laLiaison.portDepart.nom}}</td>
            <td>{{traversee.laLiaison.portArrivee.nom}}</td>
            <td><button type=\"button\" class=\"btn btn-info\">Plus d'infos</button></td>
            </tr>
            
        {% endfor %}
    
    
  </tbody>
  </div>
</table>
{% endblock %}
", "liste_traversees/index.html.twig", "/var/www/html/SicilyLines/templates/liste_traversees/index.html.twig");
    }
}
